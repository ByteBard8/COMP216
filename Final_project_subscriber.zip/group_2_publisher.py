import paho.mqtt.client as mqtt
from paho.mqtt.properties import Properties
from paho.mqtt.packettypes import PacketTypes
from random import randint
import time
import json

from group_2_data_generator import DataGenerator
from group_2_util import Util

datagenerator = DataGenerator(min_value=16, max_value=28)
util = Util()

# Publisher – Sending data to broker
BROKER = 'localhost'
PORT = 1883

def on_log(client, userdata, level, buf):
    print(client, userdata, level, buf)

def on_connect(client, userdata, flags, reason, properties):
    print(f'Connected with result code {reason}')

def on_publish(client, userdata, mid, reason, properties):
    print(f'Published Message ID: {mid} -- Code: {reason}')

def on_disconnect(client, userdata, flags, reason, properties):
    print(f'Disconnected with result code {reason}')
    client.loop_stop()

con_properties = Properties(PacketTypes.CONNECT)
con_properties.SessionExpiryInterval = 30

publ_properties = Properties(PacketTypes.PUBLISH)
publ_properties.MessageExpiryInterval = 5

client_pub = mqtt.Client(protocol=mqtt.MQTTv5)
client_pub.on_log = on_log
client_pub.on_connect = on_connect
client_pub.on_publish = on_publish
client_pub.on_disconnect = on_disconnect

client_pub.connect(BROKER, PORT, 60, properties=con_properties)
client_pub.loop_start()

try:
    while True:
        data = util.create_data(datagenerator)
        # Ensure 'packet_id' is part of the data
        data['packet_id'] = randint(1000, 9999)  # Generate a random packet_id
        data_formatted = json.dumps(data)
        client_pub.publish('data/temp', data_formatted, qos=2, retain=True, properties=publ_properties)
        print(f'Successfully published data: {data_formatted}')
        time.sleep(2)

except KeyboardInterrupt:
    print("Publisher is stopping...")
    client_pub.disconnect()
    client_pub.loop_stop()
