import random
from time import asctime
import platform
from json import dumps  # Ensure this is included at the top of your script

class Util:
    max_temp = 26
    min_temp = 16

    def __init__(self):
        self.start_id = 111

    def create_data(self, generator):
        self.start_id += 1
        platform_processor = platform.processor()
        current_temp = random.uniform(self.min_temp, self.max_temp)  # Random temperature within range
        current_feels_like = current_temp + random.gauss(0, 1.5)  # Feels like temperature close to actual temp
        
        latitude = random.uniform(-90.0, 90.0)
        longitude = random.uniform(-180.0, 180.0)
        humidity = random.randint(0, 100)
        weather_main = random.choice(['sunny', 'rain', 'thunderstorm', 'mist', 'snow', 'scattered clouds', 'broken clouds', 'windy'])
        temp_min = random.uniform(self.min_temp, current_temp)
        temp_max = random.uniform(current_temp, self.max_temp)
        unit = 'deg C'

        data = {
            'packet_id': self.start_id,  # Use start_id as packet_id
            'time': asctime(),
            'platform': platform_processor,
            'location': {'lat': latitude, 'lng': longitude},
            'temperature': {
                'current': round(current_temp, 1),
                'feels_like': round(current_feels_like, 1),
                'min': round(temp_min, 1),
                'max': round(temp_max, 1),
                'unit': unit
            },
            'humidity': humidity,
            'weather': weather_main
        }
        return data

    def print_data(self, data):
        print(dumps(data, indent=4))

# Example usage:
# util = Util()
# generator = DataGenerator(min_value=16, max_value=28)  # Assuming DataGenerator class has been properly defined
# for x in range(5):
#     data = util.create_data(generator)
#     util.print_data(data)
